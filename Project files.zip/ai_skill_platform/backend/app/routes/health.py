"""
Health Check Route
Basic health and status checks for the API
"""

from fastapi import APIRouter, Depends
from datetime import datetime
from app.models.schemas import HealthResponse
from utils import sql_connector, blob_client

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health_check():
    """
    Health check endpoint - no authentication required.
    Returns status of API and dependent services.
    """
    
    # Check database
    db_status = "healthy" if sql_connector.test_connection() else "unhealthy"
    
    # Check Blob Storage
    blob_status = "healthy"
    try:
        blob_client.list_blobs("datasets")
    except Exception:
        blob_status = "unhealthy"
    
    return HealthResponse(
        status="healthy" if db_status == "healthy" and blob_status == "healthy" else "degraded",
        version="1.0.0",
        timestamp=datetime.utcnow(),
        database=db_status,
        blob_storage=blob_status
    )


@router.get("/status")
async def status():
    """Detailed status information."""
    return {
        "api": "running",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat(),
        "environment": "production"
    }
