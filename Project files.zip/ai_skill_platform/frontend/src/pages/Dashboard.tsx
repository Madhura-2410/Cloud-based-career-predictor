import React from 'react';
import { SkillHeatmap } from '../components/SkillHeatmap';
import { TrendGraph } from '../components/TrendGraph';
import { FrequencyChart } from '../components/FrequencyChart';
import { FiLayout, FiTrendingUp, FiTarget, FiZap } from 'react-icons/fi';

const Dashboard: React.FC = () => {
    return (
        <div className="min-h-screen bg-gray-50 pb-12">
            {/* Header section */}
            <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="bg-blue-600 p-2 rounded-lg">
                                <FiLayout className="text-white" size={24} />
                            </div>
                            <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">
                                Skill Intelligence Dashboard
                            </h1>
                        </div>
                        <div className="flex items-center gap-4">
                            <div className="text-sm text-gray-500 font-medium">
                                Last updated: {new Date().toLocaleDateString()}
                            </div>
                            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors shadow-sm">
                                Refresh Data
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Quick Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <StatCard
                        title="Total Job Postings"
                        value="12,482"
                        change="+14%"
                        icon={<FiTrendingUp className="text-green-500" />}
                    />
                    <StatCard
                        title="Rising Skills"
                        value="42"
                        change="+5"
                        icon={<FiZap className="text-yellow-500" />}
                    />
                    <StatCard
                        title="Market Efficiency"
                        value="86%"
                        change="-2%"
                        icon={<FiTarget className="text-blue-500" />}
                        isRed={true}
                    />
                    <StatCard
                        title="Active Users"
                        value="1,204"
                        change="+82"
                        icon={<FiLayout className="text-purple-500" />}
                    />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    {/* Main Charts Column */}
                    <div className="lg:col-span-8 space-y-8">
                        <section id="skill-heatmap">
                            <SkillHeatmap />
                        </section>

                        <section id="industry-trends">
                            <TrendGraph />
                        </section>
                    </div>

                    {/* Sidebar Column */}
                    <div className="lg:col-span-4 space-y-8">
                        <section id="skill-frequency">
                            <FrequencyChart />
                        </section>

                        {/* Quick Actions / Tips */}
                        <div className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-xl shadow-xl p-6 text-white">
                            <h3 className="text-xl font-bold mb-4">AI Insights</h3>
                            <p className="text-blue-100 text-sm mb-6 leading-relaxed">
                                Python and React continue to dominate the AI job market. We've detected a 15% increase in demand for "Cloud Architecture" skills this quarter.
                            </p>
                            <button className="w-full bg-white text-blue-700 font-bold py-3 rounded-lg hover:bg-blue-50 transition-colors">
                                Generate Full Report
                            </button>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

interface StatCardProps {
    title: string;
    value: string;
    change: string;
    icon: React.ReactNode;
    isRed?: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, change, icon, isRed }) => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 transition-all hover:shadow-md">
        <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-gray-50 rounded-lg">{icon}</div>
            <span className={`text-xs font-bold px-2 py-1 rounded-full ${isRed ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'
                }`}>
                {change}
            </span>
        </div>
        <div className="text-gray-500 text-sm font-medium mb-1">{title}</div>
        <div className="text-2xl font-extrabold text-gray-900">{value}</div>
    </div>
);

export default Dashboard;
