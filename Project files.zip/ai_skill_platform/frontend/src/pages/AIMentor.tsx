import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { FiMessageSquare, FiTrendingUp, FiCheckCircle, FiChevronRight } from 'react-icons/fi';

const AIMentor: React.FC = () => {
    const [guidance, setGuidance] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchGuidance = async () => {
            try {
                const userId = "user_123";
                const data = await api.getMentorGuidance(userId);
                setGuidance(data);
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        fetchGuidance();
    }, []);

    if (loading) return <div className="p-12 text-center text-xl animate-pulse">Consulting with your AI Mentor...</div>;

    return (
        <div className="max-w-5xl mx-auto px-4 py-12">
            <div className="flex items-center gap-6 mb-12">
                <div className="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center shadow-lg transform hover:scale-105 transition-transform">
                    <FiMessageSquare className="text-white text-3xl" />
                </div>
                <div>
                    <h1 className="text-4xl font-extrabold text-gray-900">{guidance?.mentor_name}</h1>
                    <p className="text-indigo-600 font-semibold uppercase tracking-widest text-sm">Artificial Intelligence Guide</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Main Conversation Area */}
                <div className="lg:col-span-2 space-y-6">
                    <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 relative">
                        <div className="absolute -left-3 top-8 w-6 h-6 bg-white transform rotate-45 border-l border-b border-gray-100"></div>
                        <p className="text-xl text-gray-700 leading-relaxed font-medium italic">
                            "{guidance?.summary}"
                        </p>
                    </div>

                    <div className="bg-indigo-50 p-8 rounded-3xl border border-indigo-100">
                        <h3 className="font-bold text-indigo-900 mb-4 flex items-center gap-2">
                            <FiTrendingUp /> Strategic Advice
                        </h3>
                        <p className="text-indigo-800 leading-relaxed">
                            {guidance?.primary_advice}
                        </p>
                    </div>

                    <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
                        <h3 className="text-2xl font-bold text-gray-900 mb-8">Your Personalized Roadmap</h3>
                        <div className="space-y-8 relative">
                            <div className="absolute left-4 top-2 bottom-2 w-0.5 bg-gray-100"></div>
                            {guidance?.roadmap_steps.map((step: any, i: number) => (
                                <div key={i} className="flex gap-6 relative group">
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm z-10 transition-colors ${i === 0 ? 'bg-indigo-600 text-white shadow-md' : 'bg-white border-2 border-gray-200 text-gray-400 group-hover:border-indigo-400 group-hover:text-indigo-500'
                                        }`}>
                                        {step.step}
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-gray-900 text-lg flex items-center gap-2">
                                            {step.title} {i === 0 && <FiCheckCircle className="text-green-500 text-sm" />}
                                        </h4>
                                        <p className="text-gray-600 mt-1">{step.action}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Sidebar Insights */}
                <div className="space-y-8">
                    <div className="bg-gradient-to-br from-indigo-900 to-blue-900 p-8 rounded-3xl text-white shadow-xl">
                        <h3 className="text-lg font-bold mb-4 opacity-80">Next Milestone</h3>
                        <div className="text-2xl font-bold mb-6">{guidance?.next_milestone}</div>
                        <div className="w-full bg-indigo-800 h-2 rounded-full overflow-hidden">
                            <div className="bg-indigo-400 h-full w-1/3 shadow-[0_0_10px_rgba(129,140,248,0.5)]"></div>
                        </div>
                        <p className="mt-4 text-sm opacity-60">33% Progress</p>
                    </div>

                    <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
                        <h3 className="text-gray-500 uppercase text-xs font-black tracking-widest mb-6">Daily Wisdom</h3>
                        <p className="text-gray-900 font-bold text-lg leading-snug">
                            {guidance?.motivation_quote}
                        </p>
                        <button className="mt-8 flex items-center gap-2 text-indigo-600 font-bold hover:gap-4 transition-all">
                            Discuss with Mentor <FiChevronRight />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AIMentor;
