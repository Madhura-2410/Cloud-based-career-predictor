import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { MsalProvider } from '@microsoft/msal-react';
import { PublicClientApplication } from '@microsoft/msal-browser';

// Pages
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Profile from './pages/Profile';
import SkillsPage from './pages/SkillsPage';
import Predictions from './pages/Predictions';
import AIMentor from './pages/AIMentor';

// Configuration
const msalConfig = {
  auth: {
    clientId: process.env.REACT_APP_AAD_CLIENT_ID,
    authority: process.env.REACT_APP_AAD_AUTHORITY,
    redirectUri: window.location.origin,
    postLogoutRedirectUri: '/'
  },
  cache: {
    cacheLocation: 'localStorage'
  }
};

const pca = new PublicClientApplication(msalConfig);

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if user is already authenticated
    const accounts = pca.getAllAccounts();
    if (accounts.length > 0) {
      setIsAuthenticated(true);
    }
  }, []);

  return (
    <MsalProvider instance={pca}>
      <Router>
        <div className="min-h-screen bg-gray-100">
          <Routes>
            <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/skills" element={<SkillsPage />} />
            <Route path="/predictions" element={<Predictions />} />
            <Route path="/mentor" element={<AIMentor />} />
            <Route path="/" element={isAuthenticated ? <Dashboard /> : <Login setIsAuthenticated={setIsAuthenticated} />} />
          </Routes>
        </div>
      </Router>
    </MsalProvider>
  );
}

export default App;
